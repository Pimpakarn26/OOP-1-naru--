package com.npru.se65;

public class TestDriver {

	public static void main(String[] args) {
		Rectangle r1 = new Rectangle();
		r1.setLength(6);
		r1.setWidth(5);
		System.out.println(r1.toString());
		
		Triangle t1 = new Triangle();
		t1.setBase(6);
		t1.setHeight(5);
		System.out.println(t1.toString());
		
		Rectangle r2 = new Rectangle();
		r2.setLength(6);
		r2.setWidth(5);
		System.out.println(r1.toString());
		
		System.out.println("Check r1 and r2 : identity :"+r1.equals(r2));
		
		Rectangle r3 = new Rectangle();
		r3 = r1;
		System.out.println("Check r1 and r3 : identity :"+r1.equals(r3));
		System.out.println(r3.toString());
		r3.setLength(6);
		System.out.println(r3.toString());
		System.out.println(r1.toString());

	}

}
