package com.npru.se65;

public abstract class Shape {
	private String color;
	
	abstract public double getArea(); 
	abstract public String toString();
}
